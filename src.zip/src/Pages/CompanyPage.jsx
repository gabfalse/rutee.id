import React from "react";

function CompanyPage() {
  return <div>CompanyPage</div>;
}

export default CompanyPage;
