import React from "react";

function GroupPage() {
  return <div>GroupPage</div>;
}

export default GroupPage;
